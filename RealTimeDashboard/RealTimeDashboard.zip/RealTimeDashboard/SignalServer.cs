﻿using Microsoft.AspNetCore.SignalR;

namespace RealTimeDashboard
{
    public class SignalServer:Hub
    {

    }
}